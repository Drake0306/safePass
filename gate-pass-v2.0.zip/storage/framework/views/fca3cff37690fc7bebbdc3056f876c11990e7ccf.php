<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">

    <title>E-SafePass System</title>
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!--
    =========================================================
    * ArchitectUI HTML Theme Dashboard - v1.0.0
    =========================================================
    * Product Page: https://dashboardpack.com
    * Copyright 2019 DashboardPack (https://dashboardpack.com)
    * Licensed under MIT (https://github.com/DashboardPack/architectui-html-theme-free/blob/master/LICENSE)
    =========================================================
    * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
    -->
    <?php echo $__env->make('script&css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        div.app-container.app-theme-white.body-tabs-shadow.fixed-sidebar.fixed-header {
            /* font-size: 12px; */
        }

        .add-padding-left {
            padding-left: 50px;
        }

        .table-hover tbody tr:hover {
            background-color: #f7964600;
        }
    </style>
</head>

<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="app-main">
        <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="app-main__outer">
            <div class="app-main__inner">
                <div class="row">
                    <div class="col-md-12" style="">
                        <div class="main-card mb-3 card">
                            <div class="card-header text-dark">Report Temporary Labour
                                <div class="btn-actions-pane-right">
                                    <div role="group" class="btn-group-sm btn-group">
                                        <form action="<?php echo e(url('labour/report/generate')); ?>">
                                            <input type="hidden" name="from_date" value="<?php echo e($from_date); ?>">
                                            <input type="hidden" name="to_date" value="<?php echo e($to_date); ?>">
                                            <button class="active btn bg-danger text-light" type="submit">PRINT PDF</button>
                                        </form>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive" style="overflow: scroll">
                                <table class="align-middle mb-0 table-sm table-hover" style="width: 200%;">
                                    <thead class="thead-dark" style="border: 1px solid black;">
                                        <tr style="border: 1px solid black;">
                                            <th class="text-center" style="width: 5%"></th>
                                            <th style="width:"></th>
                                            <th style="width:"></th>
                                            <th style="width:"></th>
                                            <th style="width:"></th>
                                            <th style="width:"></th>
                                            <th style="width:"></th>
                                            <th style="width:"></th>
                                            <th style="width:"></th>
                                            <th style="text-align: center;border: 1px solid black;" colspan="2"> Police Verification</th>
                                            <th style="width:"></th>
                                            <th style="width:"></th>
                                            <th style="text-align: center;border: 1px solid black;" colspan="2"> Card Valid</th>
                                            <th style="width:"></th>
                                        </tr>
                                        <tr style="border: 1px solid black;">
                                            <th class="text-center" style="border: 1px solid black;5%">#</th>
                                            <th style="border: 1px solid black;">Issue Date</th>
                                            <th style="border: 1px solid black;">Card No</th>
                                            <th style="border: 1px solid black;">Party Name</th>
                                            <th style="border: 1px solid black;">Type</th>
                                            <th style="border: 1px solid black;">Name</th>
                                            <th style="border: 1px solid black;"> Fathers Name</th>
                                            <th style="border: 1px solid black;"> Address</th>
                                            <th style="border: 1px solid black;">Aadhar</th>
                                            <th style="border: 1px solid black;" colspan="1">Number</th>
                                            <th style="border: 1px solid black;" colspan="1">Date</th>
                                            <th style="border: 1px solid black;"> Police Station</th>
                                            <th style="border: 1px solid black;"> Blood Group</th>
                                            <th style="border: 1px solid black;" colspan="1">From</th>
                                            <th style="border: 1px solid black;" colspan="1">To</th>
                                            <th style="border: 1px solid black;"> No of Renewal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $labour_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $party = DB::table('party_master')->where('sap_code',$item->party)->first();
                                            $labour_type = DB::table('labour_type')->where('id',$item->type)->first();
                                        ?>

                                        <tr>
                                            <td class="text-center text-muted">#<?php echo e($key + 1); ?></td>
                                            <td>
                                                <?php echo e(date('d-m-Y',strtotime(@$item->issue_date))); ?>

                                            </td>
                                            <td><?php echo e(@$item->card_number); ?></td>
                                            <td><?php echo e(@$party->party_name); ?></td>
                                            <td><?php echo e(@$labour_type->name); ?></td>
                                            <td>
                                                <div class="widget-content p-0">
                                                    <div class="widget-content-wrapper">
                                                        <div class="widget-content-left me-3">
                                                            <div class="widget-content-left">
                                                                <?php if($item->upload_photo_documents): ?>
                                                                <img width="40" height="40" class="rounded-circle"
                                                                    src="<?php echo e(url('../public/files/'.$item->upload_photo_documents)); ?>"
                                                                    alt="">
                                                                <?php else: ?>
                                                                <img width="40" height="40" class="rounded-circle"
                                                                    src="<?php echo e(url('../public/files/1642441947.png')); ?>"
                                                                    alt="">
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="widget-content-left">
                                                            <div class="widget-heading"><?php echo e(@$item->full_name); ?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="">
                                                <?php echo e(@$item->fathers_name); ?>

                                            </td>
                                            <td class="">
                                                <?php echo e(@$item->house); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/truck/data/scan/edit/'.$item->id)); ?>"
                                                    data-toggle="tooltip"
                                                    title="<?php echo e(@$item->adhar_no); ?> ( click to edit )"><?php echo e(substr(@$item->adhar_no, 0, 20)); ?>

                                                    ..</a>
                                            </td>
                                            
                                        
                                            <td class="">
                                                <?php echo e(@$item->ref); ?>

                                            </td>
                                            <td class="">
                                                <?php echo e(date('d-m-Y',strtotime(@$item->valid_from))); ?>

                                            </td>

                                            <td class="">
                                                <?php echo e(@$item->police_station); ?>

                                            </td>
                                            <td class="">
                                                <?php echo e(@$item->blood_group); ?>

                                            </td>

                                            <td class="">
                                                <?php echo e(date('d-m-Y',strtotime(@$item->card_valid_from))); ?>

                                            </td>
                                            <td class="">
                                                <?php echo e(date('d-m-Y',strtotime(@$item->card_valid_to))); ?>

                                            </td>
                                            <td class="">
                                                <?php echo e(@$item->renual_count); ?>

                                            </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php if($value ?? '' == 1): ?>
                                <?php echo e(@$labour_data->links()); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
</body><?php /**PATH C:\xampp\htdocs\gate-pass-v2.0\resources\views/labourReportList.blade.php ENDPATH**/ ?>