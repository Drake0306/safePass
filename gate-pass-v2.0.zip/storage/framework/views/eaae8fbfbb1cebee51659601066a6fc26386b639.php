<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">

    <title>Analytics Dashboard - This is an example dashboard created using build-in elements and components.</title>
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!--
    =========================================================
    * ArchitectUI HTML Theme Dashboard - v1.0.0
    =========================================================
    * Product Page: https://dashboardpack.com
    * Copyright 2019 DashboardPack (https://dashboardpack.com)
    * Licensed under MIT (https://github.com/DashboardPack/architectui-html-theme-free/blob/master/LICENSE)
    =========================================================
    * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
    -->
    <link href="<?php echo e(url('public/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('public/main.css')); ?>" rel="stylesheet">
    <style>
        div.app-container.app-theme-white.body-tabs-shadow.fixed-sidebar.fixed-header {
            /* font-size: 12px; */
        }
    </style>
</head>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="" style="text-transform:uppercase"><b id="text_change">gate entry system</b></div>
                <input type="hidden" name="" id="value_data_one" value="0">
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" id="change_no" class="hamburger close-sidebar-btn hamburger--elastic"
                            data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button"
                        class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>
            <div class="app-header__content">
                <div class="app-header-left">
                    <div class="search-wrapper">
                        <div class="input-holder">
                        </div>
                        <button class="close"></button>
                    </div>
                    <ul class="header-menu nav">
                        <li class="nav-item">
                            <a href="javascript:void(0);" class="nav-link">
                                <i class="nav-link-icon fa fa-database"> </i>
                                Statistics
                            </a>
                        </li>
                        <li class="btn-group nav-item">
                            <a href="javascript:void(0);" class="nav-link">
                                <i class="nav-link-icon fa fa-edit"></i>
                                Projects
                            </a>
                        </li>
                        <li class="dropdown nav-item">
                            <a href="javascript:void(0);" class="nav-link">
                                <i class="nav-link-icon fa fa-cog"></i>
                                Settings
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="app-header-right">
                    <div class="header-btn-lg pr-0">
                        <div class="widget-content p-0">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left">
                                    <div class="btn-group">
                                        <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                            class="p-0 btn">
                                            <i class="fa fa-user-circle" style="font-size:30px;" aria-hidden="true"></i>
                                            <i class="fa fa-angle-down ml-2 opacity-8"></i>
                                        </a>
                                        <div tabindex="-1" role="menu" aria-hidden="true"
                                            class="dropdown-menu dropdown-menu-right">
                                            <a href="<?php echo e(url('log_out')); ?>" tabindex="0" class="dropdown-item">Log Out</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="app-main">
        <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="app-main__outer">
                <div class="app-main__inner">

                    <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div class="mb-3 card">

                                    <div class="card-header-tab card-header-tab-animation card-header">
                                        <div class="card-header-title">
                                            <i class="header-icon lnr-apartment icon-gradient bg-love-kiss"> </i>
                                            <?php echo e($name); ?>

                                        </div>

                                    </div>
                                    <div class="card-body">
                                        <div class="tab-content">
                                            <form action="<?php echo e(url('/blacklist/labour/add')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                              <select class="form-control" name="aadhar_no" id="" required >
                                                                <option value="" >Aadhar Number Select</option>
                                                                <?php $__currentLoopData = $labour_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item['adhar_no']); ?>" ><?php echo e($item['adhar_no']); ?> || <?php echo e($item['full_name']); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                              </select>
                                                        </div>

                                                    </div>
                                                    <div class="col-md-2">
                                                        <button type="submit" class="btn btn-outline-danger"
                                                            style="width:100%;height:40px;"> <i class="fa fa-plus-circle" aria-hidden="true"></i> &nbsp; BLACKLIST THIS </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">

                                    <div class="card-header-tab card-header-tab-animation card-header">
                                        <div class="card-header-title">
                                            <i class="header-icon lnr-apartment icon-gradient bg-love-kiss"> </i>
                                            LIST
                                        </div>

                                    </div>

                                    <div class="tab-content">
                                        <div class="row">
                                            <div class="col-md-12">

                                                <div class="main-card mb-3 card">
                                                    <div class="card-body">
                                                    <div class="tab-content">
                                                            <form action="<?php echo e(url('/blacklist/search/labour')); ?>" method="get">
                                                                <div class="row">
                                                                    <div class="col-md-10">
                                                                        <div class="form-group">
                                                                            <input type="text" class="form-control" name="search" id=""
                                                                                aria-describedby="helpId" placeholder="Aadhar Number Search">
                                                                        </div>

                                                                    </div>
                                                                    
                                                                    <!-- <div class="col-md-2">
                                                                        <div class="form-group">
                                                                            <select class="form-control" name="type" id="">
                                                                                <option value="1">ALL</option>
                                                                                <option value="4">PENDING OUT</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> -->
                                                                    <div class="col-md-2">
                                                                        <button type="submit" class="btn btn-outline-primary"
                                                                            style="width:100%;height:40px;"><i class="fa fa-search"
                                                                                aria-hidden="true"></i>&nbsp; Search</button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                        <br>
                                                        <table class="mb-0 table table-borderless">
                                                            <thead>
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th style="text-align: center">Action</th>
                                                                    <th>BlackList Aadhar Number</th>
                                                                    <th>Location Code</th>
                                                                    </th>
                                                                </tr>
                                                            </thead>
                                                            <tbody style="font-size:12px;">
                                                                <?php $c = 1; ?>
                                                                <?php $__currentLoopData = $blacklistList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php //echo $item->party_name;?>
                                                                <tr>
                                                                    <th scope="row"><?php echo e($c++); ?></th>
                                                                    <td style="text-align: center" >
                                                                    <a href="<?php echo e(url('/revert/blacklist/labour/'.$item->id)); ?>" 
                                                                       onclick="return confirm('Are you sure?')" 
                                                                       title="Delete Consignment"> 
                                                                       <i class="fa fa-trash text-danger" style="font-size: 20px;" aria-hidden="true"></i>
                                                                    </a> 
                                                                 </td>
                                                                    <th scope="row"> <lable class="text-primary" > <b style="letter-spacing: 1px" ><?php echo e($item->aadhar); ?></b> </lable> </th>
                                                                    <th scope="row"><?php echo e($item->location); ?></th>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                        <?php if($value ?? '' == 1): ?>
                                                        <?php echo e(@$labour_data->links()); ?>

                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>


                    </div>
                    <!-- <div class="app-wrapper-footer">
                        <div class="app-footer">
                            <div class="app-footer__inner">
                                <div class="app-footer-left">
                                    <ul class="nav">
                                        <li class="nav-item">
                                            <a href="javascript:void(0);" class="nav-link">
                                                Footer Link 1
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="javascript:void(0);" class="nav-link">
                                                Footer Link 2
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="app-footer-right">
                                    <ul class="nav">
                                        <li class="nav-item">
                                            <a href="javascript:void(0);" class="nav-link">
                                                Footer Link 3
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="javascript:void(0);" class="nav-link">
                                                <div class="badge badge-success mr-1 ml-0">
                                                    <small>NEW</small>
                                                </div>
                                                Footer Link 4
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </div>
                <!--<script src="http://maps.google.com/maps/api/js?sensor=true"></script>-->
            </div>
        </div>
        <script type="text/javascript" src="<?php echo e(url('public/assets/scripts/main.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(url('public/script.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
        <script type="text/javascript" src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js">
        </script>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        
</body>

</html><?php /**PATH C:\xampp\htdocs\gate-pass-v2.0\resources\views/blacklistLabour.blade.php ENDPATH**/ ?>