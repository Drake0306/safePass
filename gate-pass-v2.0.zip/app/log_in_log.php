<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class log_in_log extends Model
{
    public $timestamps = false;
    public  $table = "log_in_log";
}