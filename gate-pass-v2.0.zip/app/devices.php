<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class devices extends Model
{
    public $timestamps = false;
    public  $table = "devices";
}
