<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class party_master extends Model
{
    public $timestamps = false;
    public  $table = "party_master";
}
