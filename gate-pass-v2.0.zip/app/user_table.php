<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class user_table extends Model
{
   public $timestamps = false;
    public  $table = "user_table";
}
