<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class labour_type extends Model
{
   public $timestamps = false;
    public  $table = "labour_type";
}
