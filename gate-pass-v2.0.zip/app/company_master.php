<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class company_master extends Model
{
    public $timestamps = false;
    public  $table = "company_master";
}