<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class catagory_master extends Model
{
    public $timestamps = false;
    public  $table = "catagory_master";
}
