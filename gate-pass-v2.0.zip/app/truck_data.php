<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class truck_data extends Model
{
    public $timestamps = false;
    public  $table = "truck_data";
}