<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class no_of_visit extends Model
{
   public $timestamps = false;
    public  $table = "no_of_visit";
}
