<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="{{url('public/assets/fonts/hindi.css')}}">
    <link href="{{url('public/assets/fonts/KrutiDev010.woff')}}">
    
    <style>
    @font-face {
        font-family: 'Kruti Dev 010';
        src: url('{{url("public/assets/fonts/KrutiDev010.woff2")}}') format('woff2'),
            url('{{url("public/assets/fonts/KrutiDev010.woff")}}') format('woff');
        font-weight: normal;
        font-style: normal;
        font-display: swap;
    }

    .KrutiDev_hindi_text {
        font-family: 'Kruti Dev 010';
        font-weight: normal;
        font-style: normal;
    }
    </style>
</head>

<body>
    <table width="100%" style="border: 1px solid black" >
            <tr>
                <th>Image</th>
                <th>
                    <u class="KrutiDev_hindi_text" >bafM;u v‚;y d‚j~iksZjs'ku fyfeVsM</u>
                    <br>
                    Indian Oil Corporation Limited
                </th>
                <th>Space</th>
            </tr>
            <tr>
                <td>sda</td>
                <td>sa</td>
                <td>sa</td>
            </tr>
            
    </table>
</body>

</html>